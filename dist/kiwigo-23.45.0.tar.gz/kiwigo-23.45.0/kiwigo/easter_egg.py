

class CityLights:
    def __init__(self):
        pass

    def you(self):
        print('g: You? ')
        print('b: You can see now? ')
        print('g: Yes, I can see now. ')
        print('THE END')